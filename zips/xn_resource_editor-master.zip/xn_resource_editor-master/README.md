This is an unofficial mirror of XN Resource Editor. I created it since the files are no longer available from the author.

Please see the website for more details: https://stefansundin.github.io/xn_resource_editor/
